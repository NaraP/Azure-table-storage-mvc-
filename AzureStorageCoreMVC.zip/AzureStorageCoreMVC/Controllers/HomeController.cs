﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AzureStorageCoreMVC.Models;
using AzureStorageCoreMVC.MovieServices;

namespace AzureStorageCoreMVC.Controllers
{
    public class HomeController : BaseController
    {
        private readonly IMovieService service;
        public HomeController(IMovieService service)
        {
            this.service = service;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var model = await service.GetMovies();

            var outputModel = ToOutputModel(model);
            return Ok(outputModel);
        }
        private List<MovieOutputModel> ToOutputModel(List<Movie> model)
        {
            //return model.Select(item => ToOutputModel(item))
            //            .ToList();
            return null;
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
